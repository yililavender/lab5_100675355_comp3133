import { Customer } from './customer'
let customer = new Customer("John", "Smith",28);
customer.greeter();
customer.getAge(28);