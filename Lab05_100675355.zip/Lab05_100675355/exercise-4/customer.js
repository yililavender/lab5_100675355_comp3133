"use strict";
exports.__esModule = true;
exports.Customer = void 0;
var Customer = /** @class */ (function () {
    function Customer(firstName, lastName, age) {
        this.age = age;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    Customer.prototype.getAge = function (age) {
        this.age = age;
        console.log("".concat(this.age, " "));
    };
    Customer.prototype.greeter = function () {
        console.log("Hello ".concat(this.firstName, " ").concat(this.lastName));
    };
    return Customer;
}());
exports.Customer = Customer;
var customer = new Customer("John", "Smith", 20);
customer.greeter();
customer.getAge(20);
// export class Customer
