export class Customer {
    private firstName: string;
    private lastName:string;

    constructor(firstName:string, lastName:string, private age:number){
        this.firstName=firstName;
        this.lastName=lastName;
    }
    public getAge(age:number){
        this.age = age
        console.log(`${this.age} `);
    }

    public greeter(){
        console.log(`Hello ${this.firstName} ${this.lastName}`);
    }



}

let customer = new Customer("John","Smith",20)
customer.greeter();
customer.getAge(20);
// export class Customer
